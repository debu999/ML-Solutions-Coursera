print("Reader __init__.py is getting executed")

from reader.reader import Reader





