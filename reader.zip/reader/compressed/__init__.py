print("Importing compressed package")

print("using __all__ to specify what all to be imported from this package")

__all__ = ['bz2_opener', 'gzip_opener']